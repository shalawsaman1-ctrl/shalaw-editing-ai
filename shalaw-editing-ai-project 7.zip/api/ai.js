// Vercel serverless function. Set HF_TOKEN in Vercel Project Settings > Environment Variables.
module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const token = process.env.HF_TOKEN;
  if (!token) return res.status(503).json({ error: "HF_TOKEN is not configured in Vercel." });
  const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
  const language = ["ckb", "en", "ar"].includes(req.body?.language) ? req.body.language : "ckb";
  if (!prompt || prompt.length > 4000) return res.status(400).json({ error: "Enter a prompt up to 4000 characters." });
  const languageName = language === "en" ? "English" : language === "ar" ? "Arabic" : "Sorani Kurdish";
  try {
    const response = await fetch("https://router.huggingface.co/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "Qwen/Qwen2.5-7B-Instruct",
        messages: [
          { role: "system", content: `You are Shalaw Editing's creative assistant. Reply in ${languageName}. Help users improve photo/video editing ideas and write detailed prompts for image-editing tools. Be clear that you provide instructions/prompts and do not claim you edited an image unless you actually did.` },
          { role: "user", content: prompt }
        ],
        max_tokens: 600,
        temperature: 0.7
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status >= 500 ? 502 : response.status).json({ error: data.error?.message || data.error || "Hugging Face inference request failed. Check model availability and token permissions." });
    const result = data.choices?.[0]?.message?.content;
    if (!result) return res.status(502).json({ error: "The AI provider returned no text." });
    return res.status(200).json({ result });
  } catch (err) {
    return res.status(502).json({ error: "Could not connect to the AI provider." });
  }
};
