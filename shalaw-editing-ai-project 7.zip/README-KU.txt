Shalaw Editing — پڕۆژەی ئامادە بۆ Vercel

ناوەڕۆک:
- index.html: وێبسایتەکە و وێنەی کەسییەکەت لە ناو فایلەکەدا هەیە.
- api/ai.js: API route بۆ پەیوەندی بە Hugging Face Inference Router.

گرنگ: ئەم پڕۆژەیە پێویستە وەک پڕۆژەی Vercel deploy بکرێت؛ تەنها drag/drop کردنی index.html API route ـەکە کارا ناکات.

هەنگاوەکانی بڵاوکردنەوە:
1) فایلەکانی ئەم ZIP ـە بکەرەوە.
2) فولدەری شالاو-ئیدیتینگ-پڕۆژەکە لە GitHub repository ـێکدا upload بکە (index.html لە root و api/ai.js لە ناو فولدەری api).
3) لە Vercel، Add New Project بکە و repository ـەکە import بکە.
4) لە Project Settings > Environment Variables، ناوی HF_TOKEN و نرخەکەی (کلیلی Hugging Face) زیاد بکە. کلیلەکە لە کۆد یان GitHub مەنووسە.
5) Redeploy بکە.
6) لە وێبسایتەکە، بەشی AI تاقی بکەرەوە.

تێبینی: HF_TOKEN پێویستە مۆڵەتی Inference داشته‌بێت و مۆدێلی دیاریکراو لە پلانی بەکارهێنانەکەتدا بەردەست بێت. بەکارهێنانی خۆڕایی سنووردارە و دڵنیایی نییە هەمیشە بەردەست بێت. ئەم بەشە وەڵامی دەقی AI و پرۆمپت دروست دەکات، بەڵام هێشتا image-to-image editing جێبەجێ ناکات.
